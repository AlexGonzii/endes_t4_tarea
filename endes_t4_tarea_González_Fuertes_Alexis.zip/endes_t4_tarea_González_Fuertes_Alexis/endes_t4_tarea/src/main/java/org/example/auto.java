package org.example;
/**
 * Clase que representa un coche
 * La clase coche representa un coche que se usará para viajar
 * @author Alexis
 * @version 1.0, 20/02/24
 */
public class auto {

    /**
     * Marca de un coche
     */

        private String marca;

     /**
      * Modelo de un coche
      */
        private String modelo;

      /**
       * Constructor de objetos de la clase auto
       * El constructor contiene los atributos necesarios
       * @param marca La marca del coche
       * @param modelo El modelo del coche
       */
        public auto(String marca, String modelo) {
            this.marca = marca;
            this.modelo = modelo;
        }

        /**
         * Método getter para marca
         * Devuelve string con la marca
         */
        public String getMarca() {
            return marca;
        }
        /**
         * Método setter para marca
         * Asignamos la marca del coche
         */

        public void setMarca(String marca) {
            this.marca = marca;
        }
        /**
         * Método getter para modelo
         * Devuelve string con el modelo
         */
        public String getModelo() {
            return modelo;
        }
        /**
         * Método setter para modelo
         * Asiganamos el modelo del coche*/

        public void setModelo(String modelo) {
            this.modelo = modelo;
        }
        /**
        *Método que convierte la estancia en un String
        *El metodo devuelve un String con toda la informacion necesaria
        *@return Un String con información sobre la marca y el modelo del coche
        */

        @Override
        public String toString() {
            return "Auto [marca=" + marca + ", modelo=" + modelo + "]";
        }
    }

