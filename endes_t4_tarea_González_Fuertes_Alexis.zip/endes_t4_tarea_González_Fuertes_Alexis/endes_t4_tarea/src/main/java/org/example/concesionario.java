package org.example;

import java.util.ArrayList;
/**
 * Clase que representa un concesionario
 * La clase concesionario representa un lugar en el que se reparan,venden y mantienen coches
 * @author Alexis
 * @version 1.0 20/02/24*/
public class concesionario {

    /**
     * ArrayList sobre autos
     * Permite modificar y almacenar los datos sobre coches
     */
    private ArrayList<auto> autos;

    /**
     *Constructor de la clase concesionario
     * Autos se añade al ArrayList */
    public concesionario() {
        autos = new ArrayList<>();
    }
    /**
     * Método vacío para agregar un coche
     */

    public void agregarAuto(auto auto) {
        autos.add(auto);
    }

    /**
     * Método para listar coches
     * Devuelve los coches
     */
    public ArrayList<auto> listarAutos() {
        return autos;
    }
    /**
     * Método para imprimir los coches
     * No devuelve nada
     * Dentro de este se realiza un bucle for con coches
     */

    public void imprimirAutos(){
        for (auto auto: autos){
            System.out.println(auto);
        }
    }
}
